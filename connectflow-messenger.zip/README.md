# ConnectFlow Messenger

منصة تواصل اجتماعي متكاملة تعمل في الوقت الفعلي مع ميزات messaging، مشاركة الصور، رسائل صوتية، وملصقات.

## 🚀 النشر السريع

### الخيار 1: Railway (مجاني)
```bash
# تسجيل الدخول
railway login

# ربط المشروع
railway init

# نشر
railway up
```

### الخيار 2: Render (مجاني)
1. اذهب إلى https://dashboard.render.com
2. سجّل الدخول بحساب GitHub
3. اضغط "New Web Service"
4. اختر هذا المستودع
5. الإعدادات:
   - Build Command: `npm install`
   - Start Command: `npm start`
6. اضغط "Create Web Service"

### الخيار 3: Heroku
```bash
# تثبيت Heroku CLI
npm install -g heroku

# تسجيل الدخول
heroku login

# إنشاء التطبيق
heroku create connectflow-messenger

# نشر
git push heroku master
```

### الخيار 4: VPS/Linux Server
```bash
# استنساخ المشروع
git clone https://github.com/your-username/connectflow-messenger.git
cd connectflow-messenger

# تثبيت الاعتماديات
npm install

# تشغيل في الخلفية باستخدام PM2
npm install -g pm2
pm2 start server.js --name "connectflow-messenger"
pm2 startup
pm2 save

# إعداد Nginx (اختياري)
sudo nano /etc/nginx/sites-available/connectflow
```

## 📋 المتطلبات

- Node.js 18+
- npm أو yarn
- قاعدة بيانات SQLite (مضمنة تلقائياً)

## ⚙️ الإعدادات البيئية

```env
PORT=3000
NODE_ENV=production
JWT_SECRET=your-super-secret-key-change-this
```

## 📁 هيكل المشروع

```
connectflow-messenger/
├── server.js              # الخادم الرئيسي
├── package.json           # إعدادات npm
├── Procfile              # للنشر على المنصات السحابية
├── connectflow.db        # قاعدة البيانات (يُنشأ تلقائياً)
├── public/
│   ├── index.html        # الصفحة الرئيسية
│   ├── css/
│   │   └── style.css     # التنسيقات
│   ├── js/
│   │   └── app.js        # تطبيقات العميل
│   └── avatars/          # صور الملفات الشخصية
└── uploads/              # الصور والرسائل الصوتية
```

## 🎨 المميزات

- ✅ **المسجّلة الفورية**: تواصل فوري باستخدام Socket.io
- ✅ **إرسال الصور**: مشاركة الصور والملفات
- ✅ **الرسائل الصوتية**: تسجيل وإرسال رسائل صوتية
- ✅ **الملصقات والإيموجي**: مجموعة متنوعة من الملصقات
- ✅ **دليل المستخدم**: عرض جميع المستخدمين المتصلين
- ✅ **مؤشر الكتابة**: عرض عندما يكتب الآخرون
- ✅ **تحديد حالة الاتصال**: معرفة من متصل ومن غير متصل
- ✅ **الرسائل المحفوظة**: حفظ جميع الرسائل في قاعدة البيانات
- ✅ **تصميم متجاوب**: يعمل على جميع الأجهزة
- ✅ **دعم العربية**: واجهة مستخدم عربية كاملة

## 🛠️ التطوير المحلي

```bash
# استنساخ المشروع
git clone https://github.com/your-username/connectflow-messenger.git
cd connectflow-messenger

# تثبيت الاعتماديات
npm install

# تشغيل الخادم
npm start

# فتح المتصفح
# http://localhost:3000
```

## 📱 الاستخدام

1. **إنشاء حساب**: اضغط "إنشاء حساب" وأدخل اسم المستخدم وكلمة المرور
2. **تسجيل الدخول**: استخدم بياناتك للدخول
3. **اختيار مستخدم**: من القائمة الجانبية، اختر مستخدم للتحدث معه
4. **إرسال رسالة**: اكتب في مربع النص واضغط Enter أو زر الإرسال
5. **إرسال صورة**: اضغط أيقونة الصورة واختر ملفاً
6. **إرسال رسالة صوتية**: اضغط أيقونة الميكروفون، سجل، ثم أوقف
7. **إرسال ملصق**: اضغط أيقونة الملصقات واختر ملصقاً

## 🔒 الأمان

- تشفير كلمات المرور باستخدام bcrypt
- توكنات JWT للجلسات
- التحقق من المدخلات
- تخزين آمن للملفات

## 📊 المراقبة

للخوابات الإنتاجية، يُنصح بإضافة:
- Logs: Winston أو Pino
- Metrics: Prometheus
- Health checks: نقطة نهاية /health
- Rate limiting

## 🐳 Docker (اختياري)

```dockerfile
FROM node:18-alpine
WORKDIR /app
COPY package*.json ./
RUN npm install --production
COPY . .
EXPOSE 3000
CMD ["node", "server.js"]
```

```bash
# بناء وتشغيل
docker build -t connectflow-messenger .
docker run -p 3000:3000 connectflow-messenger
```

## 📄 الترخيص

MIT License

## 👤 المؤلف

**MiniMax Agent** - تطوير وصيانة

---

تم إنشاؤه بـ ❤️ من قبل MiniMax Agent
